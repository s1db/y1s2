package vehicle.types;

public class Bus extends MotorVehicle {
	
	public Bus(String name){
		super(name);
		setNowheels(6);
	}
}
